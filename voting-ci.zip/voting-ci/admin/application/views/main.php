	<div class="row">
		<?php if ($passdefault): ?>
		<div class="col-sm-12">
			<div class="alert alert-danger">
				<h4><i class="icon fa fa-warning"></i> Password Default !</h4>
				<p>You are still using the default password, <a href="<?=base_url('pengaturan');?>">Click Here</a> to change.</p>
			</div>
		</div>
		<?php endif?>
		<div class="col-sm-12">
			<div class="box box-success box-solid">
				<div class="box-header">
					<h4 class="box-title">Welcome</h4>
				</div>
				<div class="box-body">
					<h4>Welcome to the web-based voting application built using PHP with CodeIgniter Web Framework</h4>
				</div>
			</div>
		</div>
	</div>